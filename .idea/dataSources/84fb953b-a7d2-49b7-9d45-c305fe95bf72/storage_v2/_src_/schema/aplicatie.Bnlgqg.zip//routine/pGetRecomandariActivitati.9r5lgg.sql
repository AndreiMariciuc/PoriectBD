create
    definer = root@localhost procedure pGetRecomandariActivitati(IN idGrupa int, IN nrZi int)
begin
    drop temporary table if exists ore_disponibile;
    create temporary table ore_disponibile
    (
        ora_inceput int
    );


    insert into ore_disponibile(ora_inceput)
    values (8),
           (9),
           (10),
           (11),
           (12),
           (13),
           (14),
           (15),
           (16),
           (17),
           (18),
           (19),
           (20);


    select id_curs into @idCurs from grupe where id_grupa = idGrupa;


    select ora_inceput,
           (case
                when studActiv.`Numarul de colegi care au treaba` is null then
                    0
                else
                    studActiv.`Numarul de colegi care au treaba`
               end) as nrStudenti
    from (select* from ore_disponibile) as initOre
             left join
         (select ora_inceput        as "Ora de inceput",
                 count(ora_inceput) as "Numarul de colegi care au treaba"
          from curs_activitati
                   join studenti_activitati sa on curs_activitati.id_ca = sa.id_activitate
          where id_curs = @idCurs
            and nr_zi_sapt = nrZi
            and sa.id_student in (SELECT id_student FROM studenti_grupe WHERE id_grupa = idGrupa)
          group by ora_inceput) as studActiv
         on initOre.ora_inceput = studActiv.`Ora de inceput`
    order by nrStudenti;


    drop temporary table ore_disponibile;
end;

