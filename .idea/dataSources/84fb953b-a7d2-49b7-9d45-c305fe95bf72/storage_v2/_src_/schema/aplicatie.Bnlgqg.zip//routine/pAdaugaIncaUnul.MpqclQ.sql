create
    definer = root@localhost procedure pAdaugaIncaUnul(IN pid_activitate_grupa int)
BEGIN
    UPDATE programari_activitati_grupe SET numar_curent_participanti = numar_curent_participanti + 1 WHERE id_activitate_grupa = pid_activitate_grupa;
END;

