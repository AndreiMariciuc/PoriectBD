create view vprofnrcursanti as
select `ca`.`id_ca`              AS `id_ca`,
       `c`.`id_curs`             AS `id_curs`,
       `ca`.`id_prof_titular`    AS `id_prof_titular`,
       `c`.`denumire`            AS `denumire`,
       `c`.`descriere`           AS `descriere`,
       count(`ca`.`id_ca`)       AS `nr_actual_participanti`,
       `a`.`nr_max_participanti` AS `numar_maxim`,
       `ca`.`nr_zi_sapt`         AS `ziua`,
       `ca`.`ora_inceput`        AS `ora_inceput`,
       `ca`.`durata`             AS `durata`,
       `ca`.`perioada`           AS `perioada`
from (((`aplicatie`.`curs_activitati` `ca` join `aplicatie`.`studenti_activitati` `sa`) join `aplicatie`.`activitati` `a`)
         join `aplicatie`.`cursuri` `c`
              on (((`ca`.`id_ca` = `sa`.`id_activitate`) and (`ca`.`id_activ` = `a`.`id_activitate`) and
                   (`ca`.`id_curs` = `c`.`id_curs`))))
group by `ca`.`id_ca`
having (count(`ca`.`id_ca`) < `a`.`nr_max_participanti`);

