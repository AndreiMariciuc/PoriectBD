create
    definer = root@localhost procedure pGetGrupeBune(IN pid_student int)
BEGIN
    SELECT DISTINCT id_grupa, nume, prenume, denumire, descriere, id_profesor_raspunzator FROM vGetDetaliiGrupe WHERE id_grupa IN (SELECT id_grupa
    FROM grupe 
    WHERE id_grupa NOT IN (SELECT id_grupa FROM studenti_grupe WHERE id_student = pid_student) 
        AND id_curs IN (SELECT DISTINCT id_curs FROM studenti_activitati sa JOIN curs_activitati ca ON sa.id_activitate = ca.id_ca WHERE sa.id_student = pid_student));
    
END;

