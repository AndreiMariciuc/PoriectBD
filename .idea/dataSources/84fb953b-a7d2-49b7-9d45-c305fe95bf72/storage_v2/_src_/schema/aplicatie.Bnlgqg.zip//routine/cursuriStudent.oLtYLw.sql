create
    definer = root@localhost procedure cursuriStudent(IN id_student int)
begin
    select distinct c.descriere
    from vactivitatistudent join cursuri c on vactivitatistudent.id_curs = c.id_curs
    where id_student = id_student;
end;

