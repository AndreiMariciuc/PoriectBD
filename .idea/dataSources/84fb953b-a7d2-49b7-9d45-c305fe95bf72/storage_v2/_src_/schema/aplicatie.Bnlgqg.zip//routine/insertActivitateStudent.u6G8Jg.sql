create
    definer = root@localhost procedure insertActivitateStudent(IN idStud int, IN activ int)
begin
	insert into studenti_activitati(id_student, id_activitate) values (idStud ,activ);
end;

