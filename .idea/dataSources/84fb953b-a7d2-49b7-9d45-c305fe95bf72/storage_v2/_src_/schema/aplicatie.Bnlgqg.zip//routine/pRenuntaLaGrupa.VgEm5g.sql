create
    definer = root@localhost procedure pRenuntaLaGrupa(IN pid_student int, IN pid_grupa int)
BEGIN
    SELECT id_admin_grupa INTO @id_administrator FROM grupe WHERE id_grupa = pid_grupa;
    IF @id_administrator != pid_student THEN -- Ce se intampla cu grupa ?? :O 
        DELETE FROM studenti_grupe WHERE id_student = pid_student AND id_grupa = pid_grupa;
    END IF;
END;

