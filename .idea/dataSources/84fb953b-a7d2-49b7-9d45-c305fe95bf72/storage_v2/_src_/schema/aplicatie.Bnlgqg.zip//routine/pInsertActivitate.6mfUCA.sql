create
    definer = root@localhost procedure pInsertActivitate(IN id_curs int, IN id_activ int, IN perioada int,
                                                         IN nr_zi_sapt int, IN procent int, IN id_prof_titular int,
                                                         IN id_prof_delegat int, IN ora int, IN durata int,
                                                         IN max_participanti int)
BEGIN
    set @new_id = if ((select count(*) from curs_activitati)>0,(select max(id_ca) from curs_activitati),0);
    insert into curs_activitati value (@new_id+1,id_curs,id_activ,perioada,nr_zi_sapt,procent,id_prof_titular,id_prof_delegat,ora,durata,max_participanti);
END;

