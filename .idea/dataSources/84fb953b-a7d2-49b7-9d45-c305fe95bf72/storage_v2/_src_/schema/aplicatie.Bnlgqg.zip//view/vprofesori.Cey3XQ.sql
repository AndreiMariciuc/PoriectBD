create view vprofesori as
select `aplicatie`.`profesori`.`id_profesor`              AS `id_profesor`,
       `aplicatie`.`users`.`CNP`                          AS `CNP`,
       `aplicatie`.`roluri`.`descriere_rol`               AS `descriere_rol`,
       `aplicatie`.`users`.`nume`                         AS `nume`,
       `aplicatie`.`users`.`prenume`                      AS `prenume`,
       `aplicatie`.`users`.`adresa`                       AS `adresa`,
       `aplicatie`.`users`.`nr_tel`                       AS `nr_tel`,
       `aplicatie`.`users`.`email`                        AS `email`,
       `aplicatie`.`users`.`IBAN`                         AS `IBAN`,
       `aplicatie`.`users`.`nr_contract`                  AS `nr_contract`,
       `aplicatie`.`profesori`.`nr_min_ore`               AS `nr_min_ore`,
       `aplicatie`.`profesori`.`nr_max_ore`               AS `nr_max_ore`,
       `aplicatie`.`departamente`.`cod_departament`       AS `cod_departament`,
       `aplicatie`.`departamente`.`descriere_departament` AS `descriere_departament`,
       `aplicatie`.`profesori`.`id_departament`           AS `id_departament`
from (((`aplicatie`.`users` join `aplicatie`.`profesori`) join `aplicatie`.`roluri`)
         join `aplicatie`.`departamente`
              on (((`aplicatie`.`users`.`id_user` = `aplicatie`.`profesori`.`id_profesor`) and
                   (`aplicatie`.`roluri`.`id_rol` = `aplicatie`.`users`.`id_rol`) and
                   (`aplicatie`.`departamente`.`id_departament` = `aplicatie`.`profesori`.`id_departament`))));

