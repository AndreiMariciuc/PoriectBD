create
    definer = root@localhost procedure pCreareActivitateGrupa(IN pid_grupa int, IN pnr_min int,
                                                              IN pdata_activitate_grupa date, IN pora_activitate int,
                                                              IN pdurata_activitate int, IN pdeadline int,
                                                              IN pid_student int)
BEGIN
    INSERT INTO programari_activitati_grupe 
        (id_grupa, nr_minim, numar_curent_participanti, data_activitate_grupa, ora_activitate, durata_activitate, start_programare, deadline) VALUES
        (pid_grupa, pnr_min, 0, pdata_activitate_grupa, pora_activitate, pdurata_activitate, NOW(), NOW() + INTERVAL pdeadline HOUR);
    -- call pTrimiteMesaj(IN pid_grupa INT, IN pid_from INT, IN psubiect VARCHAR(32), IN ptext TEXT, IN pprogramare TINYINT);
    SET @nume_student = (SELECT nume FROM vGetStudById WHERE id_student = pid_student);
    SET @prenume_student = (SELECT prenume FROM vGetStudById WHERE id_student = pid_student);
    SET @descriere_materie = (SELECT c.descriere FROM grupe g JOIN cursuri c ON g.id_curs = c.id_curs WHERE g.id_grupa = pid_grupa);
    SET @subiect_mesaj = concat("Programare activitate pentru aprofundare, grupa @", pid_grupa);
    SET @continut_mesaj = concat("Salutare dragi colegi, eu, ", @nume_student, " ", @prenume_student, ", va propun sa aprofundam la materia ", @descriere_materie, ", in data de: ", pdata_activitate_grupa, ", la ora: ", pora_activitate, ", cu o durata de: ", pdurata_activitate, " ore. Sa nu uitati sa acceptati invtatia!");
    SET @id_activitate = (SELECT max(id_activitate_grupa) FROM programari_activitati_grupe);
    INSERT INTO mesaje_grupe (id_from, id_grupa, subiect, continut_mesaj, timp_primire, programare) 
        VALUES (pid_student, pid_grupa, @subiect_mesaj, @continut_mesaj, NOW(), @id_activitate);
END;

