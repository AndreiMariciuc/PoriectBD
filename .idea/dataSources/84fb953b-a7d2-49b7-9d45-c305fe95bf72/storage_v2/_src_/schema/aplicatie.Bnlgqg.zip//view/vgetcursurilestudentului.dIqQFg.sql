create definer = root@localhost view vgetcursurilestudentului as
select distinct `c`.`id_curs`     AS `id_curs`,
                `c`.`denumire`    AS `denumire`,
                `c`.`descriere`   AS `descriere`,
                `sa`.`id_student` AS `id_student`
from ((`aplicatie`.`cursuri` `c` join `aplicatie`.`curs_activitati` `ca`)
         join `aplicatie`.`studenti_activitati` `sa`
              on (((`c`.`id_curs` = `ca`.`id_curs`) and (`sa`.`id_activitate` = `ca`.`id_ca`))));

