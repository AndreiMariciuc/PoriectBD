create definer = root@localhost view vstudentilacurs as
select `u`.`id_user`        AS `id_user`,
       `u`.`nume`           AS `nume_student`,
       `u`.`prenume`        AS `prenume_student`,
       `u`.`nr_tel`         AS `nr_tel`,
       `u`.`email`          AS `email`,
       `v`.`denumire_curs`  AS `denumire_curs`,
       `v`.`descriere_curs` AS `descriere_curs`,
       `v`.`nume`           AS `nume_profesor`,
       `v`.`prenume`        AS `prenume profesor`,
       `v`.`id_ca`          AS `id_ca`
from ((`aplicatie`.`users` `u` join `aplicatie`.`studenti_activitati` `sa`)
         join `aplicatie`.`vcursuri` `v`
              on (((`u`.`id_user` = `sa`.`id_student`) and (`sa`.`id_activitate` = `v`.`id_ca`))))
order by `v`.`id_ca`;

