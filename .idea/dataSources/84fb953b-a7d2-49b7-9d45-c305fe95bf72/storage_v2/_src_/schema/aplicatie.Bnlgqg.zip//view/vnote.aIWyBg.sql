create definer = root@localhost view vnote as
select `ca`.`id_ca`              AS `id_ca`,
       `ca`.`id_curs`            AS `id_curs`,
       `s`.`id_student`          AS `id_student`,
       `sa`.`nota`               AS `nota`,
       `c`.`denumire`            AS `denumire_materie`,
       `ca`.`procent`            AS `procent`,
       `a`.`denumire_activitate` AS `tip_activitate`,
       `u`.`nume`                AS `nume_prof`,
       `u`.`prenume`             AS `prenume_prof`
from (((((`aplicatie`.`studenti_activitati` `sa` join `aplicatie`.`curs_activitati` `ca`) join `aplicatie`.`activitati` `a`) join `aplicatie`.`studenti` `s`) join `aplicatie`.`cursuri` `c`)
         join `aplicatie`.`users` `u`
              on (((`s`.`id_student` = `sa`.`id_student`) and (`sa`.`id_activitate` = `a`.`id_activitate`) and
                   (`c`.`id_curs` = `ca`.`id_curs`) and (`u`.`id_user` = `ca`.`id_prof_titular`))));

