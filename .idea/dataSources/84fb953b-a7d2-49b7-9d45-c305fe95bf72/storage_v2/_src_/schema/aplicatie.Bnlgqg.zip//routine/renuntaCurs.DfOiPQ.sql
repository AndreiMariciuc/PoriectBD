create
    definer = root@localhost procedure renuntaCurs(IN id_student int, IN descriereCurs varchar(128))
begin
	select id_curs into @idCurs from cursuri where descriere = descriereCurs;
    
    delete
    from studenti_activitati
    where id_activitate in (select id_ca from curs_activitati where id_curs = @idCurs)
      and id_student = id_student;
end;

