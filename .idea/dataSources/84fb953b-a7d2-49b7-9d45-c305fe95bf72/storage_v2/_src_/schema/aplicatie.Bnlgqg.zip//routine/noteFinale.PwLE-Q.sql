create
    definer = root@localhost procedure noteFinale(IN idStud int)
begin
    select distinct c.descriere as "Disciplina",
                    concat(u.nume, concat(' ', u.prenume)) as "Profesor",
                    truncate(sum(nota * (procent / 100)), 2) as "Nota"
    from curs_activitati ca
             join cursuri c
             join users u
             join studenti_activitati sa
                  on ca.id_ca = sa.id_activitate and c.id_curs = ca.id_curs and u.id_user = ca.id_prof_titular
    where sa.id_student = idStud
    group by c.descriere, concat(u.nume, concat(' ', u.prenume))
    having count(sa.id_activitate) = count(sa.nota);
end;

