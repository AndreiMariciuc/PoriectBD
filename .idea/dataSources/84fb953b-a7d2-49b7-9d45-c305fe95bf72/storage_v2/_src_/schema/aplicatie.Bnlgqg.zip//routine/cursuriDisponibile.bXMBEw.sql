create
    definer = root@localhost procedure cursuriDisponibile(IN idStud int)
begin
    select*
    from vAllCursuri
    where vAllCursuri.descriere not in (select c.descriere
                                       from cursuri c
                                                join curs_activitati ca
                                                join studenti_activitati sa
                                                join studenti s
                                                     on c.id_curs = ca.id_curs and ca.id_ca = sa.id_activitate and
                                                        sa.id_student = s.id_student
                                                         and s.id_student = idStud);
end;

