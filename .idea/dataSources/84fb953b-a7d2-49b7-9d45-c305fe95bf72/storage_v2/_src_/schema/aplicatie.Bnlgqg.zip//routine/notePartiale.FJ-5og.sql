create
    definer = root@localhost procedure notePartiale(IN idStud int)
begin
    select c.descriere                            as "Disciplina",
           a.denumire_activitate                  as "Activitate",
           concat(u.nume, concat(' ', u.prenume)) as "Profesor",
           sa.data_notare                         as "Data",
           sa.nota                                as "Nota",
           ca.procent                             as "Procent"
    from curs_activitati ca
             join users u
             join activitati a
             join cursuri c
             join studenti_activitati sa
                  on ca.id_ca = sa.id_activitate and ca.id_curs = c.id_curs and ca.id_prof_delegat = u.id_user and
                     a.id_activitate = ca.id_activ
    where id_student = idStud;
end;

