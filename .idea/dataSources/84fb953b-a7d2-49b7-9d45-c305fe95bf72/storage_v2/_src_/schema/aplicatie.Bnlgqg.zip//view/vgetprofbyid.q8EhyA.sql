create definer = root@localhost view vgetprofbyid as
select `p`.`id_profesor` AS `id_profesor`, `u`.`nume` AS `nume`, `u`.`prenume` AS `prenume`
from (`aplicatie`.`users` `u`
         join `aplicatie`.`profesori` `p` on ((`u`.`id_user` = `p`.`id_profesor`)));

