create
    definer = root@localhost procedure getActivitatiCurs(IN idCurs int, IN idStudent int, IN idProfTitular int,
                                                         IN idActivitate int)
begin
    select *
    from curs_activitati ca
    where ca.id_curs = idCurs
      and ca.id_prof_titular = idProfTitular
      and idActivitate = ca.id_activ
      and (ca.perioada, ca.nr_zi_sapt, ca.ora_inceput) not in
          (select perioada, nr_zi_sapt, ora_inceput from vActivitatiStudent where id_student = idStudent)
    union
    select *
    from curs_activitati ca
    where ca.id_curs = idCurs
      and ca.id_prof_titular = idProfTitular
      and idActivitate = ca.id_activ
      and (ca.perioada, ca.nr_zi_sapt) in (select perioada, nr_zi_sapt
                                           from vActivitatiStudent
                                           where id_student = idStudent
                                               and (ca.ora_inceput < vActivitatiStudent.ora_inceput and
                                                    vActivitatiStudent.ora_inceput - ca.ora_inceput >= ca.durata)
                                              or (ca.ora_inceput > vActivitatiStudent.ora_inceput and
                                                  ca.ora_inceput - vActivitatiStudent.ora_inceput >=
                                                  vActivitatiStudent.durata))
    union
    select *
    from curs_activitati ca
    where ca.id_curs = idCurs
      and ca.id_prof_titular = idProfTitular
      and idActivitate = ca.id_activ
      and (ca.perioada, ca.nr_zi_sapt, ca.ora_inceput) in (select perioada, nr_zi_sapt, ora_inceput
                                                           from vActivitatiStudent
                                                           where id_student = idStudent
                                                             and ((ca.perioada = 0 and perioada = 1) or
                                                                  ca.perioada = 1 and perioada = 0));
end;

