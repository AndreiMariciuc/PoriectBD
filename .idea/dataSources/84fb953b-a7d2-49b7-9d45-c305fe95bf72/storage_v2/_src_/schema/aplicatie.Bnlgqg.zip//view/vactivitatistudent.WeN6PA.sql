create view vactivitatistudent as
select `ca`.`id_ca`                                   AS `id_ca`,
       `ca`.`id_curs`                                 AS `id_curs`,
       `ca`.`id_activ`                                AS `id_activ`,
       `ca`.`perioada`                                AS `perioada`,
       `ca`.`nr_zi_sapt`                              AS `nr_zi_sapt`,
       `ca`.`procent`                                 AS `procent`,
       `ca`.`id_prof_titular`                         AS `id_prof_titular`,
       `ca`.`id_prof_delegat`                         AS `id_prof_delegat`,
       `ca`.`ora_inceput`                             AS `ora_inceput`,
       `ca`.`durata`                                  AS `durata`,
       `ca`.`nr_max_participanti`                     AS `nr_max_participanti`,
       `aplicatie`.`studenti_activitati`.`id_student` AS `id_student`
from (`aplicatie`.`studenti_activitati`
         join `aplicatie`.`curs_activitati` `ca`
              on ((`ca`.`id_ca` = `aplicatie`.`studenti_activitati`.`id_activitate`)));

