create
    definer = root@localhost procedure pCreareGrupa(IN pid_student int, IN pid_curs int)
BEGIN
	-- putea sa fie si trigger
	INSERT INTO grupe (id_curs, id_admin_grupa, id_profesor_raspunzator) VALUES (pid_curs, pid_student, NULL);
    SET @id_grupa_creata = (SELECT max(id_grupa) FROM grupe);
    INSERT INTO studenti_grupe VALUES (pid_student, @id_grupa_creata); 
END;

