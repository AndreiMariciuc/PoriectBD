create view vgetlistasutdentilagrupe as
select `u`.`nume`                       AS `nume_student`,
       `u`.`prenume`                    AS `prenume_student`,
       `vgdg`.`id_student`              AS `id_student`,
       `vgdg`.`id_grupa`                AS `id_grupa`,
       `vgdg`.`nume`                    AS `nume`,
       `vgdg`.`prenume`                 AS `prenume`,
       `vgdg`.`denumire`                AS `denumire`,
       `vgdg`.`descriere`               AS `descriere`,
       `vgdg`.`id_profesor_raspunzator` AS `id_profesor_raspunzator`
from (`aplicatie`.`vgetdetaliigrupe` `vgdg`
         join `aplicatie`.`users` `u` on ((`u`.`id_user` = `vgdg`.`id_student`)));

