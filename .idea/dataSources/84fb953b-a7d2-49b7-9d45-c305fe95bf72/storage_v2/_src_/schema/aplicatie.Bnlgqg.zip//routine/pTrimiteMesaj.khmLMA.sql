create
    definer = root@localhost procedure pTrimiteMesaj(IN pid_grupa int, IN pid_from int, IN psubiect varchar(32),
                                                     IN ptext text, IN pprogramare tinyint)
BEGIN
    INSERT INTO mesaje_grupe (id_from, id_grupa, subiect, continut_mesaj, timp_primire, programare) VALUES (pid_from, pid_grupa, psubiect, ptext, NOW(), pprogramare);
END;

