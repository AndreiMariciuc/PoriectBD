create
    definer = root@localhost procedure pInsertExamen(IN tip_exam int, IN data_desf datetime, IN durata int, IN activ_curs int)
BEGIN
    set @new_id = if ((select count(*) from examinari)>0,(select max(id_examinari) from examinari),0);
    insert into examinari value(@new_id+1,tip_exam,data_desf,durata,activ_curs);
END;

