create
    definer = root@localhost procedure calendar(IN idStud int)
begin
    select data_inceput into @dataInceput from an_universitar;
    select floor(datediff(current_date(), @dataInceput) / 7) % 2 into @tipActivitate;
    select c.descriere                                  as "Disciplina",
           a.denumire_activitate                        as "Activitate",
           p.descriere                                  as "Perioada",
           vas.nr_zi_sapt                               as "Zi",
           vas.ora_inceput                              as "Ora de inceput",
           vas.durata                                   as "Durata",
           concat(prof.nume, concat(' ', prof.prenume)) as "Nume Profesor"
    from vactivitatistudent vas
             join cursuri c
             join users prof
             join perioade p
             join activitati a
                  on vas.id_prof_delegat = prof.id_user and vas.id_curs = c.id_curs and vas.perioada = p.id_perioada and
                     vas.id_activ = a.id_activitate
    where id_student = idStud
      and (vas.perioada >= 2 or perioada = @tipActivitate)
    order by Zi, vas.ora_inceput;
end;

