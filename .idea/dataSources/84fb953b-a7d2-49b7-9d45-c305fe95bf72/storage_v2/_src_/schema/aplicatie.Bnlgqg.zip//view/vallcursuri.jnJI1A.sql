create definer = root@localhost view vallcursuri as
select `aplicatie`.`cursuri`.`descriere` AS `descriere`
from `aplicatie`.`cursuri`;

