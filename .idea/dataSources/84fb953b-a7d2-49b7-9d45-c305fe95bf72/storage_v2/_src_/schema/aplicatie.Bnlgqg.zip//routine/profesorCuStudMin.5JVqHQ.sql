create
    definer = root@localhost procedure profesorCuStudMin(IN idCurs int)
begin
    select id_prof_titular, count(id_student) nrStud
    from curs_activitati ca
             join studenti_activitati sa on ca.id_ca = sa.id_activitate
    where id_curs = idCurs
    group by id_prof_titular
    order by nrStud
    limit 1;
end;

