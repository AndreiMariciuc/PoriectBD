create
    definer = root@localhost procedure profesorCuStudMin(IN idCurs int)
begin
    select id_prof_titular as idProf, count(distinct id_student) as nrStud
    from curs_activitati ca
             left join studenti_activitati sa on ca.id_ca = sa.id_activitate
    where id_curs = idCurs
    group by id_prof_titular
    having count(id_student)<(select nr_max_participanti from curs_activitati where id_curs = idCurs and id_prof_titular = idProf and id_activ = 1)
    order by nrStud;
end;

