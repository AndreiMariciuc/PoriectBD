create
    definer = root@localhost procedure pDeleteActivitate(IN curs int, IN activitate int)
BEGIN
    delete from curs_activitati where id_curs = curs and id_activ = activitate;
    delete from studenti_activitati where id_activitate in (select id_ca from curs_activitati where id_curs = curs and id_activ = activitate);
END;

