create view vcursuri as
select `c`.`id_curs`             AS `id_curs`,
       `ca`.`id_ca`              AS `id_ca`,
       `c`.`denumire`            AS `denumire_curs`,
       `c`.`descriere`           AS `descriere_curs`,
       `ca`.`nr_zi_sapt`         AS `nr_zi_sapt`,
       `ca`.`ora_inceput`        AS `ora_inceput`,
       `a`.`nr_max_participanti` AS `nr_max_participanti`,
       `u`.`nume`                AS `nume`,
       `u`.`prenume`             AS `prenume`
from (((`aplicatie`.`curs_activitati` `ca` join `aplicatie`.`activitati` `a`) join `aplicatie`.`users` `u`)
         join `aplicatie`.`cursuri` `c`
              on (((`ca`.`id_curs` = `c`.`id_curs`) and (`ca`.`id_activ` = `a`.`id_activitate`) and
                   (`ca`.`id_prof_titular` = `u`.`id_user`))))
where (`a`.`id_activitate` = 1);

