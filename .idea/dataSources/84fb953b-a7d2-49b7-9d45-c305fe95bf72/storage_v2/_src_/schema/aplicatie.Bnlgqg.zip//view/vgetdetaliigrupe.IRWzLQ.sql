create definer = root@localhost view vgetdetaliigrupe as
select `sg`.`id_student`             AS `id_student`,
       `g`.`id_grupa`                AS `id_grupa`,
       `us`.`nume`                   AS `nume`,
       `us`.`prenume`                AS `prenume`,
       `vgcs`.`denumire`             AS `denumire`,
       `vgcs`.`descriere`            AS `descriere`,
       `g`.`id_profesor_raspunzator` AS `id_profesor_raspunzator`
from (((`aplicatie`.`vgetcursurilestudentului` `vgcs` join `aplicatie`.`studenti_grupe` `sg`) join `aplicatie`.`grupe` `g`)
         join `aplicatie`.`users` `us`
              on (((`vgcs`.`id_student` = `sg`.`id_student`) and (`sg`.`id_grupa` = `g`.`id_grupa`) and
                   (`us`.`id_user` = `g`.`id_admin_grupa`))));

