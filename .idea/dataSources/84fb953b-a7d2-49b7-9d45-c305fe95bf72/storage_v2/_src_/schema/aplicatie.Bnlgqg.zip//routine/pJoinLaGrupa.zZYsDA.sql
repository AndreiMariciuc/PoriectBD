create
    definer = root@localhost procedure pJoinLaGrupa(IN pid_student int, IN pid_grupa int)
BEGIN
	INSERT INTO studenti_grupe VALUES (pid_student, pid_grupa);
END;

