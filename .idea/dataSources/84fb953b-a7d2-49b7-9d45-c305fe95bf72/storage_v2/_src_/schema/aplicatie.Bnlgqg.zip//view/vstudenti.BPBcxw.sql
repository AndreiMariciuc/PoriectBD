create view vstudenti as
select `u`.`id_user`       AS `id_user`,
       `s`.`id_student`    AS `id_student`,
       `u`.`CNP`           AS `CNP`,
       `r`.`descriere_rol` AS `descriere_rol`,
       `u`.`nume`          AS `nume`,
       `u`.`prenume`       AS `prenume`,
       `u`.`adresa`        AS `adresa`,
       `u`.`nr_tel`        AS `nr_tel`,
       `u`.`email`         AS `email`,
       `u`.`IBAN`          AS `IBAN`,
       `u`.`nr_contract`   AS `nr_contract`,
       `s`.`an_studiu`     AS `an_studiu`,
       `s`.`nr_ore`        AS `nr_ore`,
       `sa`.`Descriere`    AS `descriere`
from (((`aplicatie`.`users` `u` join `aplicatie`.`studenti` `s`) join `aplicatie`.`roluri` `r`)
         join `aplicatie`.`status_activ` `sa`
              on (((`u`.`id_user` = `s`.`id_student`) and (`u`.`id_rol` = `r`.`id_rol`) and
                   (`sa`.`id_status` = `s`.`id_status`))));

