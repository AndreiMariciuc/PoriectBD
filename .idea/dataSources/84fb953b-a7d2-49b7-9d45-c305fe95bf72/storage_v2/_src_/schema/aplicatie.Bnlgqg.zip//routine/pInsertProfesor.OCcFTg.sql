create
    definer = root@localhost procedure pInsertProfesor(IN p_id_rol int, IN p_cnp char(13), IN p_nume varchar(64),
                                                       IN p_prenume varchar(64), IN p_adresa varchar(128),
                                                       IN p_nr_tel char(10), IN p_email varchar(64),
                                                       IN p_iban varchar(34), IN p_nr_contract int, IN p_nr_min_ore int,
                                                       IN p_nr_max_ore int, IN p_id_departament int)
BEGIN
	SET @username = concat(p_nume, '.', p_prenume, SUBSTR(p_cnp, 3, 3));
    SET @parola = concat(p_nume, SUBSTR(p_cnp, 5, 3));
	INSERT INTO users (id_rol, cnp, nume, prenume, adresa, nr_tel, email, iban, nr_contract, username, parola) VALUES (p_id_rol, p_cnp, p_nume, p_prenume, p_adresa, p_nr_tel, p_email, p_iban, p_nr_contract, @username, @parola);
    SET @id = (SELECT max(id_user) FROM users);
    INSERT INTO profesori VALUES (@id, p_nr_min_ore, p_nr_max_ore, p_id_departament);
END;

