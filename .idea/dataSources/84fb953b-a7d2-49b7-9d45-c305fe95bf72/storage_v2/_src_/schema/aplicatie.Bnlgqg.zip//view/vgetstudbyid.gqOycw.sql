create definer = root@localhost view vgetstudbyid as
select `s`.`id_student` AS `id_student`, `u`.`nume` AS `nume`, `u`.`prenume` AS `prenume`
from (`aplicatie`.`users` `u`
         join `aplicatie`.`studenti` `s` on ((`u`.`id_user` = `s`.`id_student`)));

